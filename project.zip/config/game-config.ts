export const gameConfig = {
  ageGroups: {
    '3-4': [
      {
        id: 1,
        question: "कौन-सा शब्द क अक्षर से शुरू होता है?",
        correctAnswer: "केला",
        balloons: [
          { id: "b1", letter: "आम", color: "#FF8C94" },
          { id: "b2", letter: "मछली", color: "#A8E6CF" },
          { id: "b3", letter: "केला", color: "#FFD3B6" },
          { id: "b4", letter: "गाड़ी", color: "#FFAAA5" }
        ],
        baskets: ["आम", "मछली", "केला", "गाड़ी"]
      },
      {
        id: 2,
        question: "च अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "चमच",
        balloons: [
          { id: "b5", letter: "मटका", color: "#FF8B94" },
          { id: "b6", letter: "पपीता", color: "#FFC3A0" },
          { id: "b7", letter: "गाड़ी", color: "#D5AAFF" },
          { id: "b8", letter: "चमच", color: "#85E3FF" }
        ],
        baskets: ["मटका", "पपीता", "गाड़ी", "चमच"]
      },
      {
        id: 3,
        question: "म अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "मछली",
        balloons: [
          { id: "b9", letter: "झूला", color: "#FFC8DD" },
          { id: "b10", letter: "मछली", color: "#B9FBC0" },
          { id: "b11", letter: "गिलास", color: "#FFB3BA" },
          { id: "b12", letter: "किताब", color: "#BAE1FF" }
        ],
        baskets: ["झूला", "मछली", "गिलास", "किताब"]
      },
      {
        id: 4,
        question: "ग अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "गाड़ी",
        balloons: [
          { id: "b13", letter: "गाड़ी", color: "#FFFFBA" },
          { id: "b14", letter: "मटका", color: "#BAFFC9" },
          { id: "b15", letter: "पंखा", color: "#B4F8C8" },
          { id: "b16", letter: "आम", color: "#A0C4FF" }
        ],
        baskets: ["गाड़ी", "मटका", "पंखा", "आम"]
      },
      {
        id: 5,
        question: "प अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "पपीता",
        balloons: [
          { id: "b17", letter: "पपीता", color: "#A0C4FF" },
          { id: "b18", letter: "किताब", color: "#B4F8C8" },
          { id: "b19", letter: "मछली", color: "#FF8C94" },
          { id: "b20", letter: "गिलास", color: "#A8E6CF" }
        ],
        baskets: ["पपीता", "किताब", "मछली", "गिलास"]
      },
      {
        id: 6,
        question: "ट अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "टमाटर",
        balloons: [
          { id: "b21", letter: "टमाटर", color: "#FFD3B6" },
          { id: "b22", letter: "केला", color: "#FFAAA5" },
          { id: "b23", letter: "चमच", color: "#FF8B94" },
          { id: "b24", letter: "गाड़ी", color: "#FFC3A0" }
        ],
        baskets: ["टमाटर", "केला", "चमच", "गाड़ी"]
      },
      {
        id: 7,
        question: "ब अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "बकरी",
        balloons: [
          { id: "b25", letter: "बकरी", color: "#D5AAFF" },
          { id: "b26", letter: "मछली", color: "#85E3FF" },
          { id: "b27", letter: "झूला", color: "#FFC8DD" },
          { id: "b28", letter: "किताब", color: "#B9FBC0" }
        ],
        baskets: ["बकरी", "मछली", "झूला", "किताब"]
      },
      {
        id: 8,
        question: "द अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "दरवाज़ा",
        balloons: [
          { id: "b29", letter: "दरवाज़ा", color: "#FFB3BA" },
          { id: "b30", letter: "पंखा", color: "#BAE1FF" },
          { id: "b31", letter: "गाड़ी", color: "#FFFFBA" },
          { id: "b32", letter: "मटका", color: "#BAFFC9" }
        ],
        baskets: ["दरवाज़ा", "पंखा", "गाड़ी", "मटका"]
      },
      {
        id: 9,
        question: "न अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "नल",
        balloons: [
          { id: "b33", letter: "नल", color: "#B4F8C8" },
          { id: "b34", letter: "किताब", color: "#A0C4FF" },
          { id: "b35", letter: "पपीता", color: "#FF8C94" },
          { id: "b36", letter: "गाड़ी", color: "#A8E6CF" }
        ],
        baskets: ["नल", "किताब", "पपीता", "गाड़ी"]
      },
      {
        id: 10,
        question: "फ अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "फूल",
        balloons: [
          { id: "b37", letter: "फूल", color: "#FFD3B6" },
          { id: "b38", letter: "मछली", color: "#FFAAA5" },
          { id: "b39", letter: "झूला", color: "#FF8B94" },
          { id: "b40", letter: "किताब", color: "#FFC3A0" }
        ],
        baskets: ["फूल", "मछली", "झूला", "किताब"]
      }
    ],
    '4-5': [
      {
        id: 11,
        question: "प अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "पंखा",
        balloons: [
          { id: "b41", letter: "गाड़ी", color: "#D5AAFF" },
          { id: "b42", letter: "पंखा", color: "#85E3FF" },
          { id: "b43", letter: "मटका", color: "#FFC8DD" },
          { id: "b44", letter: "झूला", color: "#B9FBC0" }
        ],
        baskets: ["गाड़ी", "पंखा", "मटका", "झूला"]
      },
      {
        id: 12,
        question: "ग अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "गिलास",
        balloons: [
          { id: "b45", letter: "मछली", color: "#FFB3BA" },
          { id: "b46", letter: "गिलास", color: "#BAE1FF" },
          { id: "b47", letter: "झूला", color: "#FFFFBA" },
          { id: "b48", letter: "किताब", color: "#BAFFC9" }
        ],
        baskets: ["मछली", "गिलास", "झूला", "किताब"]
      },
      {
        id: 13,
        question: "च अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "चप्पल",
        balloons: [
          { id: "b49", letter: "चप्पल", color: "#B4F8C8" },
          { id: "b50", letter: "मटका", color: "#A0C4FF" },
          { id: "b51", letter: "पंखा", color: "#FF8C94" },
          { id: "b52", letter: "झूला", color: "#A8E6CF" }
        ],
        baskets: ["चप्पल", "मटका", "पंखा", "झूला"]
      },
      {
        id: 14,
        question: "म अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "मटका",
        balloons: [
          { id: "b53", letter: "मटका", color: "#FFD3B6" },
          { id: "b54", letter: "गाड़ी", color: "#FFAAA5" },
          { id: "b55", letter: "किताब", color: "#FF8B94" },
          { id: "b56", letter: "झूला", color: "#FFC3A0" }
        ],
        baskets: ["मटका", "गाड़ी", "किताब", "झूला"]
      },
      {
        id: 15,
        question: "ब अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "बकरी",
        balloons: [
          { id: "b57", letter: "बकरी", color: "#D5AAFF" },
          { id: "b58", letter: "पंखा", color: "#85E3FF" },
          { id: "b59", letter: "गाड़ी", color: "#FFC8DD" },
          { id: "b60", letter: "मछली", color: "#B9FBC0" }
        ],
        baskets: ["बकरी", "पंखा", "गाड़ी", "मछली"]
      },
      {
        id: 16,
        question: "ट अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "टमाटर",
        balloons: [
          { id: "b61", letter: "टमाटर", color: "#FFB3BA" },
          { id: "b62", letter: "किताब", color: "#BAE1FF" },
          { id: "b63", letter: "गिलास", color: "#FFFFBA" },
          { id: "b64", letter: "झूला", color: "#BAFFC9" }
        ],
        baskets: ["टमाटर", "किताब", "गिलास", "झूला"]
      },
      {
        id: 17,
        question: "द अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "दरवाज़ा",
        balloons: [
          { id: "b65", letter: "दरवाज़ा", color: "#B4F8C8" },
          { id: "b66", letter: "पंखा", color: "#A0C4FF" },
          { id: "b67", letter: "मछली", color: "#FF8C94" },
          { id: "b68", letter: "गाड़ी", color: "#A8E6CF" }
        ],
        baskets: ["दरवाज़ा", "पंखा", "मछली", "गाड़ी"]
      },
      {
        id: 18,
        question: "न अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "नल",
        balloons: [
          { id: "b69", letter: "नल", color: "#FFD3B6" },
          { id: "b70", letter: "किताब", color: "#FFAAA5" },
          { id: "b71", letter: "पपीता", color: "#FF8B94" },
          { id: "b72", letter: "गाड़ी", color: "#FFC3A0" }
        ],
        baskets: ["नल", "किताब", "पपीता", "गाड़ी"]
      },
      {
        id: 19,
        question: "फ अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "फूल",
        balloons: [
          { id: "b73", letter: "फूल", color: "#D5AAFF" },
          { id: "b74", letter: "मछली", color: "#85E3FF" },
          { id: "b75", letter: "झूला", color: "#FFC8DD" },
          { id: "b76", letter: "किताब", color: "#B9FBC0" }
        ],
        baskets: ["फूल", "मछली", "झूला", "किताब"]
      },
      {
        id: 20,
        question: "श अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "शेर",
        balloons: [
          { id: "b77", letter: "शेर", color: "#FFB3BA" },
          { id: "b78", letter: "सूरज", color: "#BAE1FF" },
          { id: "b79", letter: "गाड़ी", color: "#FFFFBA" },
          { id: "b80", letter: "किताब", color: "#BAFFC9" }
        ],
        baskets: ["शेर", "सूरज", "गाड़ी", "किताब"]
      }
    ],
    '5-6': [
      {
        id: 21,
        question: "इनमें से कौन-सा शब्द च अक्षर से शुरू नहीं होता है?",
        correctAnswer: "मटका",
        balloons: [
          { id: "b81", letter: "चमच", color: "#B4F8C8" },
          { id: "b82", letter: "चूहा", color: "#A0C4FF" },
          { id: "b83", letter: "मटका", color: "#FF8C94" },
          { id: "b84", letter: "चप्पल", color: "#A8E6CF" }
        ],
        baskets: ["चमच", "चूहा", "मटका", "चप्पल"]
      },
      {
        id: 22,
        question: "श अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "शरबत",
        balloons: [
          { id: "b85", letter: "सूरज", color: "#FFD3B6" },
          { id: "b86", letter: "शरबत", color: "#FFAAA5" },
          { id: "b87", letter: "मछली", color: "#FF8B94" },
          { id: "b88", letter: "गाड़ी", color: "#FFC3A0" }
        ],
        baskets: ["सूरज", "शरबत", "मछली", "गाड़ी"]
      },
      {
        id: 23,
        question: "म अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "मछली",
        balloons: [
          { id: "b89", letter: "मछली", color: "#D5AAFF" },
          { id: "b90", letter: "गाड़ी", color: "#85E3FF" },
          { id: "b91", letter: "झूला", color: "#FFC8DD" },
          { id: "b92", letter: "किताब", color: "#B9FBC0" }
        ],
        baskets: ["मछली", "गाड़ी", "झूला", "किताब"]
      },
      {
        id: 24,
        question: "ग अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "गिलास",
        balloons: [
          { id: "b93", letter: "गिलास", color: "#FFB3BA" },
          { id: "b94", letter: "मटका", color: "#BAE1FF" },
          { id: "b95", letter: "पंखा", color: "#FFFFBA" },
          { id: "b96", letter: "किताब", color: "#BAFFC9" }
        ],
        baskets: ["गिलास", "मटका", "पंखा", "किताब"]
      },
      {
        id: 25,
        question: "प अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "पपीता",
        balloons: [
          { id: "b97", letter: "पपीता", color: "#B4F8C8" },
          { id: "b98", letter: "किताब", color: "#A0C4FF" },
          { id: "b99", letter: "झूला", color: "#FF8C94" },
          { id: "b100", letter: "गाड़ी", color: "#A8E6CF" }
        ],
        baskets: ["पपीता", "किताब", "झूला", "गाड़ी"]
      },
      {
        id: 26,
        question: "ट अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "टमाटर",
        balloons: [
          { id: "b101", letter: "टमाटर", color: "#FFD3B6" },
          { id: "b102", letter: "मछली", color: "#FFAAA5" },
          { id: "b103", letter: "गाड़ी", color: "#FF8B94" },
          { id: "b104", letter: "किताब", color: "#FFC3A0" }
        ],
        baskets: ["टमाटर", "मछली", "गाड़ी", "किताब"]
      },
      {
        id: 27,
        question: "ब अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "बकरी",
        balloons: [
          { id: "b105", letter: "बकरी", color: "#D5AAFF" },
          { id: "b106", letter: "पंखा", color: "#85E3FF" },
          { id: "b107", letter: "गाड़ी", color: "#FFC8DD" },
          { id: "b108", letter: "झूला", color: "#B9FBC0" }
        ],
        baskets: ["बकरी", "पंखा", "गाड़ी", "झूला"]
      },
      {
        id: 28,
        question: "द अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "दरवाज़ा",
        balloons: [
          { id: "b109", letter: "दरवाज़ा", color: "#FFB3BA" },
          { id: "b110", letter: "मछली", color: "#BAE1FF" },
          { id: "b111", letter: "गाड़ी", color: "#FFFFBA" },
          { id: "b112", letter: "किताब", color: "#BAFFC9" }
        ],
        baskets: ["दरवाज़ा", "मछली", "गाड़ी", "किताब"]
      },
      {
        id: 29,
        question: "न अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "नल",
        balloons: [
          { id: "b113", letter: "नल", color: "#B4F8C8" },
          { id: "b114", letter: "किताब", color: "#A0C4FF" },
          { id: "b115", letter: "पपीता", color: "#FF8C94" },
          { id: "b116", letter: "गाड़ी", color: "#A8E6CF" }
        ],
        baskets: ["नल", "किताब", "पपीता", "गाड़ी"]
      },
      {
        id: 30,
        question: "फ अक्षर से शुरू होने वाला शब्द कौन-सा है?",
        correctAnswer: "फूल",
        balloons: [
          { id: "b117", letter: "फूल", color: "#FFD3B6" },
          { id: "b118", letter: "मछली", color: "#FFAAA5" },
          { id: "b119", letter: "झूला", color: "#FF8B94" },
          { id: "b120", letter: "किताब", color: "#FFC3A0" }
        ],
        baskets: ["फूल", "मछली", "झूला", "किताब"]
      }
    ]
  },
  animations: {
    floatSpeed: 3,
    bounceHeight: 20,
    popDuration: 0.5,
    shakeDuration: 0.5,
    returnDuration: 1
  },
  audio: {
    correctFeedback: "बहुत अच्छा! सही है!",
    wrongFeedback: "फिर से कोशिश करो",
    gameComplete: "बधाई हो! आपने सभी सवाल पूरे कर लिए!"
  },
  timing: {
    questionRepeatDelay: 8000,
    nextLevelDelay: 2000
  }
};
