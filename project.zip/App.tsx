import { useState, useEffect, useCallback, useRef } from 'react';
import { Balloon } from './components/Balloon';
import { Basket } from './components/Basket';
import { GameControls, Celebration, FeedbackMessage } from './components/GameControls';
import { PlayScreen } from './components/PlayScreen';
import { AgeSelection } from './components/AgeSelection';
import { soundEngine, hindiVoice } from './utils/sound';
import { gameConfig } from './config/game-config';

interface BalloonData {
  id: string;
  letter: string;
  color: string;
  position: { x: number; y: number };
}

interface BalloonState {
  id: string;
  isPopping: boolean;
  isShaking: boolean;
  isVisible: boolean;
}

export default function App() {
  const [showPlayScreen, setShowPlayScreen] = useState(true);
  const [showAgeSelection, setShowAgeSelection] = useState(false);
  const [selectedAge, setSelectedAge] = useState<string | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [currentLevelIndex, setCurrentLevelIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [balloons, setBalloons] = useState<BalloonData[]>([]);
  const [balloonStates, setBalloonStates] = useState<Record<string, BalloonState>>({});
  const [basketPositions, setBasketPositions] = useState<Record<string, DOMRect>>({});
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const [showCelebration, setShowCelebration] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState({ show: false, message: '', type: 'correct' as 'correct' | 'wrong' | 'complete' });
  const [gameComplete, setGameComplete] = useState(false);
  const questionRepeatTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Get levels for selected age group
  const levels = selectedAge ? gameConfig.ageGroups[selectedAge as keyof typeof gameConfig.ageGroups] : [];
  const currentLevel = levels[currentLevelIndex];

  // Initialize balloons for current level
  useEffect(() => {
    if (!currentLevel || !gameStarted) return;

    const numBalloons = currentLevel.balloons.length;
    let spacing: number;
    let startX: number;

    if (numBalloons === 2) {
      spacing = 300;
      startX = window.innerWidth / 2 - 150;
    } else if (numBalloons === 4) {
      spacing = 200;
      startX = 80;
    } else {
      spacing = 250;
      startX = 100;
    }

    const initialBalloons = currentLevel.balloons.map((balloon, index) => ({
      ...balloon,
      position: {
        x: startX + index * spacing,
        y: window.innerHeight - 400
      }
    }));

    setBalloons(initialBalloons);

    const initialStates: Record<string, BalloonState> = {};
    initialBalloons.forEach(balloon => {
      initialStates[balloon.id] = {
        id: balloon.id,
        isPopping: false,
        isShaking: false,
        isVisible: true
      };
    });
    setBalloonStates(initialStates);

    // Speak question
    speakQuestion();

    // Set up repeat timer
    startQuestionRepeatTimer();

    return () => {
      if (questionRepeatTimerRef.current) {
        clearTimeout(questionRepeatTimerRef.current);
      }
    };
  }, [currentLevelIndex, gameStarted]);

  const speakQuestion = useCallback(() => {
    if (isSoundEnabled && currentLevel) {
      hindiVoice.speak(currentLevel.question);
    }
  }, [currentLevel, isSoundEnabled]);

  const startQuestionRepeatTimer = useCallback(() => {
    if (questionRepeatTimerRef.current) {
      clearTimeout(questionRepeatTimerRef.current);
    }
    questionRepeatTimerRef.current = setTimeout(() => {
      speakQuestion();
      startQuestionRepeatTimer();
    }, gameConfig.timing.questionRepeatDelay);
  }, [speakQuestion]);

  const handleBasketPositionUpdate = useCallback((letter: string, bounds: DOMRect) => {
    setBasketPositions(prev => ({
      ...prev,
      [letter]: bounds
    }));
  }, []);

  const checkBalloonOverBasket = (balloonX: number, balloonY: number): string | null => {
    // Only check baskets that are in the current level
    const currentBaskets = currentLevel.baskets;
    
    for (const [letter, bounds] of Object.entries(basketPositions)) {
      // Skip baskets that aren't in the current level
      if (!currentBaskets.includes(letter)) continue;
      
      if (
        balloonX >= bounds.left &&
        balloonX <= bounds.right &&
        balloonY >= bounds.top &&
        balloonY <= bounds.bottom
      ) {
        return letter;
      }
    }
    return null;
  };

  const handleBalloonDrop = (balloonId: string, x: number, y: number) => {
    const draggedBalloon = balloons.find(b => b.id === balloonId);
    if (!draggedBalloon || !balloonStates[balloonId]?.isVisible) {
      console.log('Balloon not found or not visible');
      startQuestionRepeatTimer();
      return;
    }

    console.log('=== DROP DEBUG ===');
    console.log('Drop position:', { x, y });
    console.log('Current level baskets:', currentLevel.baskets);
    console.log('Basket positions registered:', Object.keys(basketPositions));
    console.log('Basket positions:', basketPositions);

    const basketLetter = checkBalloonOverBasket(x, y);
    
    console.log('Balloon letter:', draggedBalloon.letter);
    console.log('Basket letter found:', basketLetter);
    console.log('Correct answer:', currentLevel.correctAnswer);
    
    if (!basketLetter) {
      // Not dropped on any basket
      console.log('Not dropped on any basket');
      startQuestionRepeatTimer();
      return;
    }

    // Check if correct: balloon matches correct answer AND dropped into matching basket
    const isCorrect = draggedBalloon.letter === currentLevel.correctAnswer && basketLetter === draggedBalloon.letter;
    
    console.log('Is correct?', isCorrect);
    console.log('==================');
    
    if (isCorrect) {
      // Correct answer
      setBalloonStates(prev => ({
        ...prev,
        [balloonId]: { ...prev[balloonId], isPopping: true }
      }));

      if (isSoundEnabled) {
        soundEngine.playPopSound();
        setTimeout(() => soundEngine.playCorrectSound(), 200);
        hindiVoice.speak(gameConfig.audio.correctFeedback);
      }

      setScore(prev => prev + 10);
      setShowCelebration(true);
      setFeedbackMessage({ show: true, message: gameConfig.audio.correctFeedback, type: 'correct' });

      setTimeout(() => {
        setBalloonStates(prev => ({
          ...prev,
          [balloonId]: { ...prev[balloonId], isVisible: false }
        }));
        setShowCelebration(false);
        setFeedbackMessage({ show: false, message: '', type: 'correct' });

        // Move to next level
        if (currentLevelIndex < levels.length - 1) {
          setTimeout(() => {
            setCurrentLevelIndex(prev => prev + 1);
          }, gameConfig.timing.nextLevelDelay);
        } else {
          // Game complete
          setTimeout(() => {
            setGameComplete(true);
            if (isSoundEnabled) {
              soundEngine.playCelebrationSound();
              hindiVoice.speak(gameConfig.audio.gameComplete);
            }
            setFeedbackMessage({ show: true, message: gameConfig.audio.gameComplete, type: 'complete' });
          }, gameConfig.timing.nextLevelDelay);
        }
      }, 500);
    } else {
      // Wrong answer
      setBalloonStates(prev => ({
        ...prev,
        [balloonId]: { ...prev[balloonId], isShaking: true }
      }));

      if (isSoundEnabled) {
        soundEngine.playWrongSound();
        hindiVoice.speak(gameConfig.audio.wrongFeedback);
      }

      setFeedbackMessage({ show: true, message: gameConfig.audio.wrongFeedback, type: 'wrong' });

      setTimeout(() => {
        setBalloonStates(prev => ({
          ...prev,
          [balloonId]: { ...prev[balloonId], isShaking: false }
        }));
        setFeedbackMessage({ show: false, message: '', type: 'wrong' });
        startQuestionRepeatTimer();
      }, 500);
    }
  };

  const handleRepeatQuestion = () => {
    speakQuestion();
    startQuestionRepeatTimer();
  };

  const handleToggleSound = () => {
    setIsSoundEnabled(prev => !prev);
    if (!isSoundEnabled) {
      hindiVoice.stop();
    }
  };

  const handleRestart = () => {
    setCurrentLevelIndex(0);
    setScore(0);
    setGameComplete(false);
    setShowPlayScreen(true);
    setShowAgeSelection(false);
    setGameStarted(false);
    setSelectedAge(null);
    setFeedbackMessage({ show: false, message: '', type: 'correct' });
  };

  const handlePlayScreenStart = () => {
    setShowPlayScreen(false);
    setShowAgeSelection(true);
  };

  const handleAgeSelection = (age: string) => {
    setSelectedAge(age);
    setShowAgeSelection(false);
    setGameStarted(true);
  };

  // Show play screen first
  if (showPlayScreen) {
    return <PlayScreen onStart={handlePlayScreenStart} isSoundEnabled={isSoundEnabled} />;
  }

  // Show age selection after play screen
  if (showAgeSelection) {
    return <AgeSelection onSelectAge={handleAgeSelection} isSoundEnabled={isSoundEnabled} />;
  }

  // Game complete screen
  if (gameComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-sky-300 via-sky-200 to-sky-100 flex items-center justify-center p-8">
        <Celebration show={true} />
        <div className="bg-white rounded-3xl shadow-2xl p-12 max-w-2xl text-center">
          <div className="text-8xl mb-6">🏆</div>
          <h1 className="text-5xl mb-4">बधाई हो!</h1>
          <p className="text-2xl text-gray-700 mb-6">
            आपने सभी स्तरों को पूरा कर लिया!
          </p>
          <div className="bg-yellow-100 rounded-2xl p-6 mb-8">
            <div className="text-xl text-gray-700 mb-2">कुल अंक</div>
            <div className="text-6xl">⭐ {score}</div>
          </div>
          <button
            onClick={handleRestart}
            className="bg-blue-500 hover:bg-blue-600 text-white px-12 py-6 rounded-2xl text-2xl shadow-lg hover:shadow-xl transition-all"
          >
            फिर से खेलें
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-300 via-sky-200 to-sky-100 overflow-hidden relative">
      {/* Decorative clouds */}
      <div className="absolute top-10 left-10 text-6xl opacity-70">☁️</div>
      <div className="absolute top-20 right-20 text-8xl opacity-60">☁️</div>
      <div className="absolute top-40 left-1/3 text-7xl opacity-50">☁️</div>
      <div className="absolute top-60 right-1/4 text-6xl opacity-70">☁️</div>

      {/* Game Controls */}
      <GameControls
        currentLevel={currentLevelIndex + 1}
        totalLevels={levels.length}
        score={score}
        isSoundEnabled={isSoundEnabled}
        onToggleSound={handleToggleSound}
        onRepeatQuestion={handleRepeatQuestion}
      />

      {/* Question Display */}
      <div className="absolute top-32 left-1/2 transform -translate-x-1/2 z-20">
        <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl px-12 py-6 border-4 border-blue-400">
          <div className="text-3xl text-center text-gray-800">
            {currentLevel?.question}
          </div>
        </div>
      </div>

      {/* Baskets */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex gap-12 z-10">
        {currentLevel?.baskets.map(letter => (
          <Basket
            key={`${currentLevelIndex}-${letter}`}
            letter={letter}
            onDrop={() => {}}
            isActive={false}
            onPositionUpdate={handleBasketPositionUpdate}
          />
        ))}
      </div>

      {/* Balloons */}
      {balloons.map(balloon => {
        const state = balloonStates[balloon.id];
        if (!state?.isVisible) return null;

        return (
          <Balloon
            key={balloon.id}
            id={balloon.id}
            letter={balloon.letter}
            color={balloon.color}
            onDragEnd={handleBalloonDrop}
            isPopping={state.isPopping}
            isShaking={state.isShaking}
            position={balloon.position}
          />
        );
      })}

      {/* Celebration */}
      <Celebration show={showCelebration} />

      {/* Feedback Message */}
      <FeedbackMessage
        show={feedbackMessage.show}
        message={feedbackMessage.message}
        type={feedbackMessage.type}
      />
    </div>
  );
}