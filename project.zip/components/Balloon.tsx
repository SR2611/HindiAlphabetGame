import { motion } from 'motion/react';

interface BalloonProps {
  id: string;
  letter: string;
  color: string;
  onDragEnd: (id: string, x: number, y: number) => void;
  isPopping: boolean;
  isShaking: boolean;
  position: { x: number; y: number };
}

export function Balloon({ 
  id, 
  letter, 
  color, 
  onDragEnd, 
  isPopping, 
  isShaking,
  position 
}: BalloonProps) {
  return (
    <motion.div
      drag
      dragMomentum={false}
      onDragEnd={(event, info) => {
        const finalX = info.point.x;
        const finalY = info.point.y;
        onDragEnd(id, finalX, finalY);
      }}
      initial={{ y: position.y, x: position.x, scale: 1 }}
      animate={
        isPopping
          ? { scale: [1, 1.3, 0], opacity: [1, 1, 0] }
          : isShaking
          ? { x: [position.x - 10, position.x + 10, position.x - 10, position.x + 10, position.x], rotate: [-5, 5, -5, 5, 0] }
          : {
              y: [position.y, position.y - 20, position.y],
              x: [position.x, position.x + 10, position.x - 10, position.x],
              rotate: [-2, 2, -2, 2, -2]
            }
      }
      transition={
        isPopping
          ? { duration: 0.5, ease: 'easeOut' }
          : isShaking
          ? { duration: 0.5, ease: 'easeInOut' }
          : {
              y: { duration: 3, repeat: Infinity, ease: 'easeInOut' },
              x: { duration: 5, repeat: Infinity, ease: 'easeInOut' },
              rotate: { duration: 4, repeat: Infinity, ease: 'easeInOut' }
            }
      }
      className="cursor-grab active:cursor-grabbing absolute"
      style={{ zIndex: 10 }}
    >
      <div className="relative">
        {/* Balloon body */}
        <motion.div
          className="relative"
          animate={!isPopping && !isShaking ? { scale: [1, 1.05, 1] } : {}}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <svg width="120" height="140" viewBox="0 0 120 140" className="drop-shadow-lg">
            {/* Balloon shape */}
            <defs>
              <radialGradient id={`gradient-${id}`} cx="35%" cy="35%">
                <stop offset="0%" stopColor={lightenColor(color, 40)} />
                <stop offset="50%" stopColor={color} />
                <stop offset="100%" stopColor={darkenColor(color, 20)} />
              </radialGradient>
              <filter id={`shadow-${id}`}>
                <feDropShadow dx="2" dy="4" stdDeviation="3" floodOpacity="0.3"/>
              </filter>
            </defs>
            
            {/* Main balloon */}
            <ellipse 
              cx="60" 
              cy="60" 
              rx="45" 
              ry="55" 
              fill={`url(#gradient-${id})`}
              filter={`url(#shadow-${id})`}
            />
            
            {/* Highlight */}
            <ellipse 
              cx="48" 
              cy="45" 
              rx="15" 
              ry="20" 
              fill="white" 
              opacity="0.4"
            />
            
            {/* Balloon tie */}
            <path
              d="M 60 115 Q 58 118 60 120 Q 62 118 60 115"
              fill={darkenColor(color, 30)}
            />
            
            {/* String */}
            <path
              d="M 60 120 Q 65 125 62 130 Q 58 135 60 140"
              stroke={darkenColor(color, 40)}
              strokeWidth="2"
              fill="none"
            />
          </svg>
          
          {/* Letter */}
          <div className="absolute inset-0 flex items-center justify-center" style={{ top: '-20px' }}>
            <span className="text-white text-4xl drop-shadow-md pointer-events-none select-none">
              {letter}
            </span>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}

// Helper functions
function lightenColor(color: string, percent: number): string {
  const num = parseInt(color.replace('#', ''), 16);
  const amt = Math.round(2.55 * percent);
  const R = Math.min(255, (num >> 16) + amt);
  const G = Math.min(255, (num >> 8 & 0x00FF) + amt);
  const B = Math.min(255, (num & 0x0000FF) + amt);
  return `#${(0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)}`;
}

function darkenColor(color: string, percent: number): string {
  const num = parseInt(color.replace('#', ''), 16);
  const amt = Math.round(2.55 * percent);
  const R = Math.max(0, (num >> 16) - amt);
  const G = Math.max(0, (num >> 8 & 0x00FF) - amt);
  const B = Math.max(0, (num & 0x0000FF) - amt);
  return `#${(0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1)}`;
}