import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX } from 'lucide-react';

interface GameControlsProps {
  currentLevel: number;
  totalLevels: number;
  score: number;
  isSoundEnabled: boolean;
  onToggleSound: () => void;
  onRepeatQuestion: () => void;
}

export function GameControls({
  currentLevel,
  totalLevels,
  score,
  isSoundEnabled,
  onToggleSound,
  onRepeatQuestion
}: GameControlsProps) {
  return (
    <div className="absolute top-4 left-4 right-4 flex justify-between items-start z-20">
      {/* Score and Level */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl px-6 py-4">
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🎯</span>
            <div>
              <div className="text-sm text-gray-600">स्तर</div>
              <div className="text-xl">
                {currentLevel} / {totalLevels}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-2xl">⭐</span>
            <div>
              <div className="text-sm text-gray-600">अंक</div>
              <div className="text-xl">{score}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-3">
        {/* Repeat Question */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onRepeatQuestion}
          className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-4 shadow-xl"
          title="प्रश्न दोहराएं"
        >
          <Volume2 size={24} />
        </motion.button>

        {/* Sound Toggle */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onToggleSound}
          className={`${
            isSoundEnabled ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-400 hover:bg-gray-500'
          } text-white rounded-full p-4 shadow-xl`}
          title={isSoundEnabled ? 'ध्वनि बंद करें' : 'ध्वनि चालू करें'}
        >
          {isSoundEnabled ? <Volume2 size={24} /> : <VolumeX size={24} />}
        </motion.button>
      </div>
    </div>
  );
}

interface CelebrationProps {
  show: boolean;
}

export function Celebration({ show }: CelebrationProps) {
  const emojis = ['🎉', '✨', '🌟', '💫', '🎊', '🎈'];

  return (
    <AnimatePresence>
      {show && (
        <div className="fixed inset-0 pointer-events-none z-50">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              initial={{
                x: Math.random() * window.innerWidth,
                y: -50,
                scale: 0,
                rotate: 0
              }}
              animate={{
                y: window.innerHeight + 100,
                scale: [0, 1.5, 1],
                rotate: Math.random() * 720 - 360
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                ease: 'easeOut',
                delay: Math.random() * 0.5
              }}
              className="absolute text-4xl"
            >
              {emojis[Math.floor(Math.random() * emojis.length)]}
            </motion.div>
          ))}
        </div>
      )}
    </AnimatePresence>
  );
}

interface FeedbackMessageProps {
  message: string;
  type: 'correct' | 'wrong' | 'complete';
  show: boolean;
}

export function FeedbackMessage({ message, type, show }: FeedbackMessageProps) {
  const bgColor = type === 'correct' || type === 'complete' ? 'bg-green-500' : 'bg-red-500';
  const emoji = type === 'correct' ? '✅' : type === 'complete' ? '🏆' : '❌';

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ scale: 0, y: 50, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0, y: -50, opacity: 0 }}
          className={`fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 ${bgColor} text-white px-12 py-8 rounded-3xl shadow-2xl z-50`}
        >
          <div className="text-center">
            <div className="text-6xl mb-4">{emoji}</div>
            <div className="text-3xl">{message}</div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
