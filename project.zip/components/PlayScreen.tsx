import { motion } from 'motion/react';
import { useEffect } from 'react';

interface PlayScreenProps {
  onStart: () => void;
  isSoundEnabled: boolean;
}

export function PlayScreen({ onStart, isSoundEnabled }: PlayScreenProps) {
  useEffect(() => {
    if (isSoundEnabled) {
      const utterance = new SpeechSynthesisUtterance('खेल शुरू करने के लिए बटन दबाएँ।');
      utterance.lang = 'hi-IN';
      utterance.rate = 0.9;
      speechSynthesis.speak(utterance);
    }

    return () => {
      speechSynthesis.cancel();
    };
  }, [isSoundEnabled]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-300 via-sky-200 to-sky-100 overflow-hidden relative flex items-center justify-center">
      {/* Decorative clouds */}
      <div className="absolute top-10 left-10 text-6xl opacity-70">☁️</div>
      <div className="absolute top-20 right-20 text-8xl opacity-60">☁️</div>
      <div className="absolute top-40 left-1/3 text-7xl opacity-50">☁️</div>
      <div className="absolute top-60 right-1/4 text-6xl opacity-70">☁️</div>

      <div className="flex items-center gap-12">
        {/* Cartoon Peacock with animations */}
        <motion.div
          animate={{
            y: [0, -10, 0],
            rotate: [0, 5, -5, 0]
          }}
          transition={{
            y: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
            rotate: { duration: 3, repeat: Infinity, ease: 'easeInOut' }
          }}
        >
          <svg width="240" height="240" viewBox="0 0 240 240" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Tail feathers - background */}
            <motion.g
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
            >
              {/* Left feather */}
              <ellipse cx="60" cy="100" rx="35" ry="70" fill="#4F46E5" transform="rotate(-20 60 100)" />
              <ellipse cx="60" cy="100" rx="25" ry="55" fill="#6366F1" transform="rotate(-20 60 100)" />
              <circle cx="60" cy="80" r="12" fill="#22D3EE" />
              <circle cx="60" cy="80" r="6" fill="#FDE047" />
              
              {/* Center-left feather */}
              <ellipse cx="90" cy="80" rx="40" ry="75" fill="#4F46E5" transform="rotate(-10 90 80)" />
              <ellipse cx="90" cy="80" rx="28" ry="60" fill="#6366F1" transform="rotate(-10 90 80)" />
              <circle cx="90" cy="55" r="14" fill="#22D3EE" />
              <circle cx="90" cy="55" r="7" fill="#FDE047" />
              
              {/* Center feather */}
              <ellipse cx="120" cy="70" rx="42" ry="80" fill="#4F46E5" />
              <ellipse cx="120" cy="70" rx="30" ry="65" fill="#6366F1" />
              <circle cx="120" cy="45" r="16" fill="#22D3EE" />
              <circle cx="120" cy="45" r="8" fill="#FDE047" />
              
              {/* Center-right feather */}
              <ellipse cx="150" cy="80" rx="40" ry="75" fill="#4F46E5" transform="rotate(10 150 80)" />
              <ellipse cx="150" cy="80" rx="28" ry="60" fill="#6366F1" transform="rotate(10 150 80)" />
              <circle cx="150" cy="55" r="14" fill="#22D3EE" />
              <circle cx="150" cy="55" r="7" fill="#FDE047" />
              
              {/* Right feather */}
              <ellipse cx="180" cy="100" rx="35" ry="70" fill="#4F46E5" transform="rotate(20 180 100)" />
              <ellipse cx="180" cy="100" rx="25" ry="55" fill="#6366F1" transform="rotate(20 180 100)" />
              <circle cx="180" cy="80" r="12" fill="#22D3EE" />
              <circle cx="180" cy="80" r="6" fill="#FDE047" />
            </motion.g>
            
            {/* Body */}
            <ellipse cx="120" cy="150" rx="35" ry="45" fill="#0EA5E9" />
            <ellipse cx="120" cy="145" rx="30" ry="38" fill="#38BDF8" />
            
            {/* Wing */}
            <ellipse cx="105" cy="150" rx="18" ry="28" fill="#0284C7" transform="rotate(-15 105 150)" />
            
            {/* Neck */}
            <ellipse cx="120" cy="120" rx="15" ry="25" fill="#0EA5E9" />
            
            {/* Head */}
            <circle cx="120" cy="105" r="22" fill="#0EA5E9" />
            <circle cx="120" cy="103" r="18" fill="#38BDF8" />
            
            {/* Crown feathers */}
            <motion.g
              animate={{ y: [0, -3, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
            >
              <circle cx="110" cy="88" r="5" fill="#4F46E5" />
              <rect x="109" y="78" width="2" height="10" fill="#4F46E5" />
              <circle cx="120" cy="85" r="5" fill="#4F46E5" />
              <rect x="119" y="75" width="2" height="10" fill="#4F46E5" />
              <circle cx="130" cy="88" r="5" fill="#4F46E5" />
              <rect x="129" y="78" width="2" height="10" fill="#4F46E5" />
            </motion.g>
            
            {/* Eyes with blink animation */}
            <motion.g
              animate={{ scaleY: [1, 0.1, 1] }}
              transition={{ duration: 3, repeat: Infinity, repeatDelay: 2 }}
            >
              <circle cx="112" cy="102" r="5" fill="white" />
              <circle cx="112" cy="102" r="3" fill="#1F2937" />
              <circle cx="113" cy="101" r="1.5" fill="white" />
              
              <circle cx="128" cy="102" r="5" fill="white" />
              <circle cx="128" cy="102" r="3" fill="#1F2937" />
              <circle cx="129" cy="101" r="1.5" fill="white" />
            </motion.g>
            
            {/* Beak */}
            <path d="M 120 108 L 135 110 L 120 112 Z" fill="#F59E0B" />
            
            {/* Legs */}
            <rect x="110" y="190" width="4" height="30" fill="#F59E0B" rx="2" />
            <rect x="126" y="190" width="4" height="30" fill="#F59E0B" rx="2" />
            
            {/* Feet */}
            <path d="M 107 220 L 102 225 M 110 220 L 110 225 M 113 220 L 118 225" stroke="#F59E0B" strokeWidth="3" strokeLinecap="round" />
            <path d="M 123 220 L 118 225 M 126 220 L 126 225 M 129 220 L 134 225" stroke="#F59E0B" strokeWidth="3" strokeLinecap="round" />
          </svg>
        </motion.div>

        {/* Play Button */}
        <motion.button
          onClick={onStart}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          animate={{
            scale: [1, 1.05, 1]
          }}
          transition={{
            scale: { duration: 1.5, repeat: Infinity, ease: 'easeInOut' }
          }}
          className="bg-gradient-to-br from-green-400 to-green-600 hover:from-green-500 hover:to-green-700 text-white px-20 py-12 rounded-full text-6xl shadow-2xl hover:shadow-3xl transition-all border-8 border-white"
        >
          <div className="flex items-center gap-6">
            <span>▶️</span>
            <span>खेलें</span>
          </div>
        </motion.button>
      </div>

      {/* Instruction text below */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="absolute bottom-20 left-1/2 transform -translate-x-1/2"
      >
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl px-8 py-4 shadow-xl border-2 border-blue-300">
          <p className="text-2xl text-gray-700 text-center">
            खेल शुरू करने के लिए बटन दबाएँ।
          </p>
        </div>
      </motion.div>

      {/* Decorative elements */}
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        className="absolute top-1/4 right-1/4 text-5xl opacity-40"
      >
        🎈
      </motion.div>
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
        className="absolute bottom-1/4 left-1/4 text-5xl opacity-40"
      >
        🎈
      </motion.div>
    </div>
  );
}