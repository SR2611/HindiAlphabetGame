import { motion } from 'motion/react';
import { useRef, useEffect } from 'react';

interface BasketProps {
  letter: string;
  onDrop: (letter: string) => void;
  isActive: boolean;
  onPositionUpdate?: (letter: string, bounds: DOMRect) => void;
}

export function Basket({ letter, onDrop, isActive, onPositionUpdate }: BasketProps) {
  const basketRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (basketRef.current && onPositionUpdate) {
      const updatePosition = () => {
        if (basketRef.current) {
          const bounds = basketRef.current.getBoundingClientRect();
          onPositionUpdate(letter, bounds);
        }
      };
      
      updatePosition();
      
      // Update on window resize
      window.addEventListener('resize', updatePosition);
      return () => window.removeEventListener('resize', updatePosition);
    }
  }, [letter, onPositionUpdate]);

  return (
    <motion.div
      ref={basketRef}
      animate={isActive ? { scale: [1, 1.1, 1] } : { scale: 1 }}
      transition={{ duration: 0.3 }}
      className="relative"
    >
      {/* Basket container */}
      <div className="flex flex-col items-center">
        {/* Basket label */}
        <motion.div
          animate={isActive ? { y: [-5, 0, -5] } : {}}
          transition={{ duration: 0.5, repeat: isActive ? Infinity : 0 }}
          className="mb-2 bg-white rounded-full px-6 py-3 shadow-lg border-4 border-amber-400"
        >
          <span className="text-5xl">{letter}</span>
        </motion.div>

        {/* Basket */}
        <svg width="150" height="120" viewBox="0 0 150 120" className="drop-shadow-xl">
          <defs>
            <linearGradient id={`basket-gradient-${letter}`} x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#D4A574" />
              <stop offset="100%" stopColor="#8B6F47" />
            </linearGradient>
            <filter id={`basket-shadow-${letter}`}>
              <feDropShadow dx="0" dy="4" stdDeviation="4" floodOpacity="0.3"/>
            </filter>
          </defs>

          {/* Basket body */}
          <path
            d="M 20 40 L 30 100 L 120 100 L 130 40 Z"
            fill={`url(#basket-gradient-${letter})`}
            filter={`url(#basket-shadow-${letter})`}
            stroke="#6B4423"
            strokeWidth="2"
          />

          {/* Basket weave pattern */}
          {[...Array(5)].map((_, i) => (
            <line
              key={`h-${i}`}
              x1="25"
              y1={50 + i * 12}
              x2="125"
              y2={50 + i * 12}
              stroke="#8B6F47"
              strokeWidth="1.5"
              opacity="0.5"
            />
          ))}
          {[...Array(8)].map((_, i) => (
            <line
              key={`v-${i}`}
              x1={30 + i * 13}
              y1="40"
              x2={32 + i * 13}
              y2="100"
              stroke="#A0826D"
              strokeWidth="1.5"
              opacity="0.4"
            />
          ))}

          {/* Basket rim */}
          <ellipse
            cx="75"
            cy="40"
            rx="55"
            ry="8"
            fill="#6B4423"
            opacity="0.7"
          />
          <ellipse
            cx="75"
            cy="38"
            rx="55"
            ry="6"
            fill="#D4A574"
          />

          {/* Handle */}
          <path
            d="M 40 38 Q 75 10 110 38"
            stroke="#8B6F47"
            strokeWidth="4"
            fill="none"
            strokeLinecap="round"
          />
        </svg>

        {/* Active indicator */}
        {isActive && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -bottom-4 text-center"
          >
            <span className="text-2xl">⬇️</span>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}