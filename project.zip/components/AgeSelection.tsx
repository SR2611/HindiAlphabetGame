import { motion } from 'motion/react';
import { useEffect } from 'react';

interface AgeSelectionProps {
  onSelectAge: (age: string) => void;
  isSoundEnabled: boolean;
}

export function AgeSelection({ onSelectAge, isSoundEnabled }: AgeSelectionProps) {
  useEffect(() => {
    if (isSoundEnabled) {
      const utterance = new SpeechSynthesisUtterance('अपनी उम्र चुनें।');
      utterance.lang = 'hi-IN';
      utterance.rate = 0.9;
      speechSynthesis.speak(utterance);
    }

    return () => {
      speechSynthesis.cancel();
    };
  }, [isSoundEnabled]);

  const ageGroups = [
    { range: '3-4', label: '३-४ साल', color: 'from-pink-400 to-pink-600', emoji: '🧸' },
    { range: '4-5', label: '४-५ साल', color: 'from-purple-400 to-purple-600', emoji: '🎨' },
    { range: '5-6', label: '५-६ साल', color: 'from-blue-400 to-blue-600', emoji: '📚' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-300 via-sky-200 to-sky-100 overflow-hidden relative flex items-center justify-center">
      {/* Decorative clouds */}
      <div className="absolute top-10 left-10 text-6xl opacity-70">☁️</div>
      <div className="absolute top-20 right-20 text-8xl opacity-60">☁️</div>
      <div className="absolute top-40 left-1/3 text-7xl opacity-50">☁️</div>
      <div className="absolute top-60 right-1/4 text-6xl opacity-70">☁️</div>

      <div className="flex flex-col items-center gap-12 px-8">
        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h1 className="text-6xl text-gray-800 mb-4">अपनी उम्र चुनें</h1>
          <p className="text-3xl text-gray-600">Select Your Age</p>
        </motion.div>

        {/* Age selection buttons */}
        <div className="flex flex-wrap justify-center gap-8 max-w-4xl">
          {ageGroups.map((group, index) => (
            <motion.button
              key={group.range}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.15, duration: 0.4 }}
              whileHover={{ scale: 1.1, rotate: 2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onSelectAge(group.range)}
              className={`bg-gradient-to-br ${group.color} hover:shadow-2xl text-white px-12 py-10 rounded-3xl shadow-xl transition-all border-6 border-white min-w-[280px]`}
            >
              <div className="flex flex-col items-center gap-4">
                <motion.span 
                  className="text-7xl"
                  animate={{ 
                    rotate: [0, -10, 10, -10, 0],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    duration: 2, 
                    repeat: Infinity,
                    delay: index * 0.3
                  }}
                >
                  {group.emoji}
                </motion.span>
                <div className="text-5xl">{group.label}</div>
                <div className="text-3xl opacity-90">{group.range} years</div>
              </div>
            </motion.button>
          ))}
        </div>

        {/* Decorative peacock at bottom */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="text-8xl mt-8"
        >
          <motion.div
            animate={{ rotate: [0, 5, -5, 0] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          >
            🦚
          </motion.div>
        </motion.div>
      </div>

      {/* Decorative elements */}
      <motion.div
        animate={{ y: [0, -20, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute top-1/4 right-1/4 text-5xl opacity-40"
      >
        🎈
      </motion.div>
      <motion.div
        animate={{ y: [0, 20, 0] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute bottom-1/4 left-1/4 text-5xl opacity-40"
      >
        🎈
      </motion.div>
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 25, repeat: Infinity, ease: 'linear' }}
        className="absolute top-1/3 left-1/5 text-4xl opacity-30"
      >
        ⭐
      </motion.div>
      <motion.div
        animate={{ rotate: -360 }}
        transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        className="absolute bottom-1/3 right-1/5 text-4xl opacity-30"
      >
        ⭐
      </motion.div>
    </div>
  );
}